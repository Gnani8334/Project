package com.bank.ui;

import java.util.Scanner;

import com.bank.bean.Customer;
import com.bank.dao.DaoImpl;
import com.bank.dao.DaoInter;
import com.bank.service.ServiceImp;

public class UserIn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		DaoInter dao = new DaoImpl();
		ServiceImp service = new ServiceImp();
		
		while (true) {

			System.out.println("enter your choice....");
			System.out.println("1.CREATE ACCOUNT");
			System.out.println("2.withdraw");
			System.out.println("3.DEPOSIT");
			System.out.println("4.SHOW BALANCE");
			System.out.println("5.FUND TRANSFER");
			System.out.println("6.PRINT TRANSACTION");
			System.out.println("7.EXIT");
			Scanner sc = new Scanner(System.in);
			Customer bean = new Customer();
			int choice = sc.nextInt();
			bean.setMinBalance(500);
			bean.getCurrBal();
			
			switch (choice) {

			case 1:
				
				System.out.println("Create account");
				System.out.println("Enter Customer Id");
				int cid = sc.nextInt();
				System.out.println("Enter Customer Name");
				String cname = sc.next();
				System.out.println("Enter Customer Addr");
				String addr = sc.next();
				System.out.println("enter phone number");
				String pn = sc.next();
				System.out.println("enter email address");
				String emailId = sc.next();
				System.out.println("enter dob");
				String dob = sc.next();

				bean.setCustomerId(cid);
				bean.setName(cname);
				bean.setAddress(addr);
				bean.setPhoneNumber(pn);
				bean.setDob(dob);
				bean.setCustomerId(cid);
				bean.setEmailId(emailId);
				bean.getAccNumber();
				bean.getPin();
				// boolean isValid = service.validateDate(bean);

				// if(isValid) {

				boolean isAdded = service.addCustomer(bean);
				// System.out.println("fff");
				if (isAdded) {
					System.out.println("Record added succesfully");
					
				} else {
					System.out.println("Record not added");
				}

				
				break;

			case 2:

				System.out.println("Withdraw:");
				System.out.println("enter the email address");
				String email = sc.next();
				System.out.println("enter the account number");
				int accNumber = sc.nextInt();
				System.out.println("enter the pin");
				int pin = sc.nextInt();
				boolean valid = service.validAccountNo(email, accNumber, pin);
				if (valid) {
					System.out.println("enter the amount to be withdraw");
					int withdraw = sc.nextInt();
					boolean validateAmount = service.validateAmount(withdraw);
					if (validateAmount) {

						int withdrawresult = service.withDraw(bean, withdraw);
						System.out.println("withdraw successful");
						System.out.println("withdrawn amount is"+withdraw);
						System.out.println(" Remaining balance is :" + withdrawresult);
					} else
						System.out.println("the amount should not be more than available amount");
				} else
					System.out.println("enter the digits only");

				break;

			case 3:
				System.out.println("deposit");
				System.out.println("enter the email address");
				String email2 = sc.next();
				System.out.println("enter the account number");
				int accNumber2 = sc.nextInt();
				System.out.println("enter the pin");
				int pin2 = sc.nextInt();
				boolean valid1 = service.validAccountNo(email2, accNumber2, pin2);
				if (valid1) {
					System.out.println("enter the amount to be deposit");
					int deposit = sc.nextInt();
					int deposit1 = service.deposit(bean, deposit);
					System.out.println("deposited successfully");
					System.out.println("the deposited amount is"+deposit);
					System.out.println("Balance is" + deposit1);

				} else
					System.out.println("Enter the valid amount");

				break;
			case 4:
				System.out.println("show");
				System.out.println("enter the email address");
				String email1 = sc.next();
				System.out.println("enter the account number");
				int accNumber1 = sc.nextInt();
				System.out.println("enter the pin");
				int pin1 = sc.nextInt();
				boolean valid2 = service.validAccountNo(email1, accNumber1, pin1);
				if (valid2) {
					int balanceAmount = service.showBalance(accNumber1);
					System.out.println("Balance is" + balanceAmount);
				} else
					System.out.println("enter valid details");
				break;
			case 5:
				System.out.println("FUND TRANSFER");
				System.out.println("enter the email address");
				String email3 = sc.next();
				System.out.println("enter the account number");
				int accNumber3 = sc.nextInt();
				System.out.println("enter the pin");
				int pin3 = sc.nextInt();
				boolean valid3 = service.validAccountNo(email3, accNumber3, pin3);
				if(valid3)
				{
					System.out.println("enter the email address");
				String email4 = sc.next();
				System.out.println("enter the account number");
				int accNumber4 = sc.nextInt();
				boolean valid4=service.verifyAcc(email4,accNumber4);
					if(valid4)
					{
						System.out.println("Enter the amount to transfer");
						int amount=sc.nextInt();
						if(amount<=bean.getCurrBal())
						{
							int camount=service.fundTransfer(amount,accNumber4);
				
						}
					}
				}
				break;
			case 6:
				System.out.println("PRINT TRANSACTION");
				
				break;
			case 7: System.exit(0);
			       break;
			default:
				System.out.println("choose the correct choice");
				break;
			}

		}
	}

	private static void exit() {
		// TODO Auto-generated method stub
		
		System.out.println("hehhehhhhh au revoir!!!!!!");
	}

}
