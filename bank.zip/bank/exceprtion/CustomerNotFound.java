package com.bank.exceprtion;

public class CustomerNotFound extends Exception {
public CustomerNotFound(String s)
{
	super(s);
}

public void getMessage(String string) {
	// TODO Auto-generated method stub
	
}

}
