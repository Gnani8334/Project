package com.bank.bean;

public class Customer {
	int accNumber=(int)((Math.random()*40000)+10000); 
	int pin=(int)((Math.random()*100)+1000); 
	String name;
	String emailId;
	int customerId;
	String phoneNumber;
	String address;
	
	public int getAccNumber() {
		return accNumber;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	public void setAccNumber(int accNumber) {
		this.accNumber = accNumber;
	}

	public int minBalance;
	public int getMinBalance() {
		return minBalance;
	}

    public double currBal=0;

	String dob;
	public double getCurrBal() {
		return currBal;
	}

	public void setCurrBal(double currBal) {
		this.currBal = currBal;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}


	
public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

@Override
	public String toString() {
		return "Customer [accNumber=" + accNumber + ", pin=" + pin + ", name=" + name + ", emailId=" + emailId
				+ ", customerId=" + customerId + ", phoneNumber=" + phoneNumber + ", address=" + address
				+ ", minBalance=" + minBalance + ", currBal=" + currBal + ", dob=" + dob + "]";
	}

public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	

			
	

	public void setPhoneNumber(String phoneNumber) {
		// TODO Auto-generated method stub
		this.phoneNumber = phoneNumber;
		
	}

	public void setMinBalance(int i) {
		this.minBalance=i;
		// TODO Auto-generated method stub
		
	}

	

	
	
}
