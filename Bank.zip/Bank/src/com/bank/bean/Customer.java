package com.bank.bean;

public class Customer
{
	
		int accNumber=(int)((Math.random()*40000)+10000); 
		int pin=(int)((Math.random()*100)+1000); 
		String name;
		String emailId;
	
		String phoneNumber;
		StringBuffer address;
		String mobileno;
		String panno;
		int age;
	    public double currBal=0;

		
		public Customer()
		{
			
			
		}


		public String getName() {
			return name;
		}


		public void setName(String name) {
			this.name = name;
		}


		public String getEmailId() {
			return emailId;
		}


		public void setEmailId(String emailId) {
			this.emailId = emailId;
		}


		public String getPhoneNumber() {
			return phoneNumber;
		}


		public void setPhoneNumber(String phoneNumber) {
			this.phoneNumber = phoneNumber;
		}


		public StringBuffer getAddress() {
			return address;
		}


		public void setAddress(StringBuffer address) {
			this.address = address;
		}


		public String getMobileno() {
			return mobileno;
		}


		public int getAccNumber() {
			return accNumber;
		}


		public void setAccNumber(int accNumber) {
			this.accNumber = accNumber;
		}


		public int getPin() {
			return pin;
		}


		public void setPin(int pin) {
			this.pin = pin;
		}


		public void setMobileno(String mobileno) {
			this.mobileno = mobileno;
		}


		public String getPanno() {
			return panno;
		}


		public void setPanno(String panno) {
			this.panno = panno;
		}


		public int getAge() {
			return age;
		}


		public void setAge(int age) {
			this.age = age;
		}


		public double getCurrBal() {
			return currBal;
		}


		public void setCurrBal(double currBal) {
			this.currBal = currBal;
		}


		@Override
		public String toString() {
			return "CustomerTest [accNumber=" + accNumber + ", pin=" + pin + ", name=" + name + ", emailId=" + emailId
					+ ", phoneNumber=" + phoneNumber + ", address=" + address + ", mobileno=" + mobileno + ", panno="
					+ panno + ", age=" + age + ", currBal=" + currBal + "]";
		}
		
		
	}

