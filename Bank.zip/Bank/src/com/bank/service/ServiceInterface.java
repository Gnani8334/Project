package com.bank.service;

import com.bank.bean.Customer;

public interface ServiceInterface {
public boolean  addCustomer(Customer c);
public int withDraw(Customer c,int withdraw);
public boolean validAccountNo(String email,int accNumber,int pin);
public boolean validateAmount(int withdraw);
public boolean validatedeposit(int deposit);
public int showBalance(int accNumber1);
public int deposit(Customer c,int deposit);
public boolean verifyAcc(String email4, int accNumber4);
 public Customer displayCust(int accNumber);
  public boolean fundTransfer( String email3, int accNumber3, int pin3,Customer a,Customer b, String email4,int accNumber4,int amount);
  public boolean validateName(String name);
  public boolean validateAge(int age);
  public boolean validatePhno(String mobileno);
  public boolean validatePan(String panno);
  public boolean validateMail(String email);
}
