package com.bank.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.bank.bean.Customer;
import com.bank.ui.*;
public class DaoImpl implements DaoInter {
	
	
	Scanner sc= new Scanner(System.in);
	int wd = sc.nextInt();
	Map<String,Customer> m=new HashMap<String,Customer>();
	Customer c = new Customer();
	Customer c1 = new Customer();



	public boolean addCustomer(Customer c) {
		// TODO Auto-generated method stub
		
	m.put(c.getEmailId(), c);
	
		Set<String> key=m.keySet();
		Iterator<String> i=key.iterator();
		while(i.hasNext())
		{
			String k=i.next();
			Customer value=m.get(k);
			
		}
		return m.containsValue(c);
		
	}

	@Override
	public int withDraw(Customer c,int wblance) {
		c.setCurrBal(wblance);
		return (int) c.getCurrBal();
	}
	public void display(){
		System.out.println(m.get(c.getEmailId()));
	}

	@Override
	public int deposit(Customer c,int de) {
		// TODO Auto-generated method stub
		c.setCurrBal(de);
		return (int) c.getCurrBal();
	}
	

	@Override
	public boolean validAccountNo(String email,int accNumber,int pin)
	{
		
		boolean flag=false;
		for(Customer c:m.values())
		{
			if((c.getEmailId()==email)&& (c.getAccNumber()==accNumber)&&(c.getPin()==pin))
			{
				flag= true;
				
			
			}
			
		}
		// TODO Auto-generated method stub
		return flag;
		
	}
	public Customer displayCust(int accNumber)
	{
		Customer cust=null;
		for (Customer c:m.values()) {
			if(c.getAccNumber()==accNumber)
					{
				cust=c;
					}
		}return cust;
		
	}

	public boolean validateAmount(int withdraw) {
		boolean flag=false;
		for(Customer c:m.values())
		{
			if((c.getCurrBal()>=withdraw) )
			{
				flag=true;
			}
		
		
	}
	
	return flag;
}

	@Override
	public int showBalance(int accNumber1) {
		int am=0;
		for(Customer c:m.values())
		{
	
			
		
		
		// TODO Auto-generated method stub
			
		
		 am=(int)c.getCurrBal();
	}
		return am;
}
	public boolean verifyAcc(String email4, int accNumber4)
	{
		boolean flag=false;
		for(Customer c:m.values())
		{
			if(c.getEmailId()==email4 || c.getAccNumber()==accNumber4)
			{
				flag= true;
				
			
			}
		
	}
		return flag;
	
}

	@Override
	public boolean fundTransfer(String email3, int accNumber3, int pin3, Customer a, Customer b, String email4,
			int accNumber4, int amount) {
		// TODO Auto-generated method stub
		boolean flag=false;	
		if((a.getEmailId()==email3)&&(a.getAccNumber()==accNumber3) && (a.getPin()==pin3))
		{
			if((b.getAccNumber()==accNumber4)&&(b.getEmailId()==email4))
			{
				if((a.getCurrBal()>amount))
				{
				int balc=0;
				int balc1=0;
				balc=a.getAccNumber()-amount;
				balc1=b.getAccNumber()+amount;
				a.setCurrBal(balc);
				b.setCurrBal(balc1);
				flag=true;
				}
			}
		
	}
		return flag;
	}
}

	



