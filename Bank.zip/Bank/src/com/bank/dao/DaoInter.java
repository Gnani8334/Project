package com.bank.dao;

import com.bank.bean.Customer;

	public interface DaoInter {
	public boolean addCustomer(Customer c);
	public int withDraw (Customer c,int wblance);
	public void display();
	public int deposit(Customer c,int de);
	public boolean validAccountNo(String email,int accNumber,int pin);
	public boolean validateAmount(int withdraw);
	public boolean validatedeposit(int deposit);
	public int showBalance(int accNumber1);

	public boolean verifyAcc(String email4, int accNumber4);
	
	public Customer displayCust( int accNumber);
	 public boolean fundTransfer( String email3, int accNumber3, int pin3,Customer a,Customer b, String email4,int accNumber4,int amount);
	
}
