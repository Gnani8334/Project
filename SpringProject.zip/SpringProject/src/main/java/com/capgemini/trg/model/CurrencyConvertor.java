package com.capgemini.trg.model;

public interface CurrencyConvertor {
	public abstract double dollarsToRupee(double dollars);
	

}
