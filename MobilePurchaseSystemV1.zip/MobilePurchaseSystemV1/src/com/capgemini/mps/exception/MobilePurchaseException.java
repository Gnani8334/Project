package com.capgemini.mps.exception;

public class MobilePurchaseException extends Exception {
private String status;
public MobilePurchaseException()
{
	status="Mobile Purchase Exception";
	
}
public String getStatus() {
	return status;
}

@Override
public String toString() {
	return "MobilePurchaseException [status=" + status + "]";
}
public MobilePurchaseException(String status) {
	super();
	this.status = status;
}

}
