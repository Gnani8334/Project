package com.capgemini.mps.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.capgemini.mps.dto.Mobile;
import com.capgemini.mps.exception.MobilePurchaseException;
import com.capgemini.mps.utility.DBConnection;

public class MobileDaoImpl  implements  IMobileDAO{

	@Override
	public Long addNewMobile(Mobile mobile)  throws MobilePurchaseException {
		// TODO Auto-generated method stub
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		try
		{
			 connection=DBConnection.getConnection();
			 preparedStatement=connection.prepareStatement(QueryMapper.INSERT_MOBILE);
			 preparedStatement.setLong(1, mobile.getMobileId());
			 preparedStatement.setString(2, mobile.getName());
			 preparedStatement.setDouble(3, mobile.getPrice());
			 preparedStatement.setInt(4, mobile.getQuantity());
			 int n=preparedStatement.executeUpdate();
			 return n*1L;
			 
		}
		catch(SQLException e)
		{
		throw new MobilePurchaseException("Unable to add"+e.getMessage());	
		}
		catch(Exception e)
		{
			throw new MobilePurchaseException(e.getMessage());
			
		}
		finally
		{
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

	@Override
	public Integer deleteMobile(Long mobileId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Mobile getMobileDetails(Long mobileId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Mobile> getAllMobileDetails() {
		// TODO Auto-generated method stub
		return null;
	}

}
