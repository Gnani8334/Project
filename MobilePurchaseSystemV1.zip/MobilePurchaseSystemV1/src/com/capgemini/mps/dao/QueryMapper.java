package com.capgemini.mps.dao;

public interface QueryMapper {
	public static final String INSERT_MOBILE="INSERT INTO MOBILES VALUES(?,?,?,?)";
	public static final String  DELETE_MOBILE="delete from mobiles where mobile_id=?";
	public static final String  SELECT_MOBILE="select *from mobiles";
}
