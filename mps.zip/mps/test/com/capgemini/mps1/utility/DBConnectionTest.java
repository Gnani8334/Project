package com.capgemini.mps1.utility;

import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.sql.SQLException;

import org.junit.Test;

import com.capgemini.mps1.exception.MobilePurchaseException;
import com.capgemini.mps1.utility.MySQLConnection;

public class DBConnectionTest {



	@Test
	public void testGetConnection() throws MobilePurchaseException, SQLException {
		try {
			assertNotNull(MySQLConnection.getConnection());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
