package com.capgemini.mps1.service;

import java.util.List;

import com.capgemini.mps1.dao.*;
import com.capgemini.mps1.dto.Mobile;
import com.capgemini.mps1.exception.MobilePurchaseException;

public class MobileServiceImpl  implements IMobileService{
	private MobileDaoImpl mobileDAO=new MobileDaoImpl();

	@Override
	public Integer addNewMobile(Mobile mobile)
			throws com.capgemini.mps1.exception.MobilePurchaseException {
		// TODO Auto-generated method stub
		return mobileDAO.addNewMobile(mobile);
		
	}

	@Override
	public Integer deleteMobile(int mobileId)
			throws MobilePurchaseException {
		// TODO Auto-generated method stub
		return mobileDAO.deleteMobile(mobileId);
	}

	@Override
	public Mobile getMobileDetails(int mobileId)
			throws MobilePurchaseException {
		// TODO Auto-generated method stub
		return mobileDAO. getMobileDetails(mobileId);
	}

	@Override
	public List<Mobile> getAllMobileDetails() throws MobilePurchaseException
			 {
		// TODO Auto-generated method stub
		return mobileDAO.getAllMobileDetails();
	}

	@Override
	public Integer updateMobilePrice(int mobileId, Double newPrice)
			throws MobilePurchaseException {
		// TODO Auto-generated method stub
		return mobileDAO.updateMobilePrice(mobileId,newPrice);
	}


	
}
