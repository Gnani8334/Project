package com.capgemini.mps1.dao;

import java.util.List;

import com.capgemini.mps1.dto.Mobile;
import com.capgemini.mps1.exception.MobilePurchaseException;

public interface IMobileDAO {

	public abstract Integer addNewMobile(Mobile mobile) throws MobilePurchaseException;
	public abstract Integer deleteMobile(int mobileId) throws MobilePurchaseException;
	public abstract Mobile getMobileDetails(int mobileId)throws MobilePurchaseException;
	public abstract List<Mobile> getAllMobileDetails()throws MobilePurchaseException;
	public abstract Integer updateMobilePrice(int mobileId,Double newPrice)throws MobilePurchaseException;
	public abstract Double getMobilePrice(int mobileId)throws MobilePurchaseException;
	public abstract Double getMobilePrice(int mobileId)throws MobilePurchaseException;
}
