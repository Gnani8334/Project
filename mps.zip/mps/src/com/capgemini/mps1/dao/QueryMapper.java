package com.capgemini.mps1.dao;

public interface QueryMapper {
	public static final String INSERT_MOBILE="INSERT INTO mobiles_n(name,price,quantity) VALUES(?,?,?)";
	public static final String  DELETE_MOBILE="delete from mobiles_n where mobile_id=?";
	public static final String  SELECT_MOBILE_ALL="select *from mobiles_n";
	public static final String  SELECT_MOBILE="select *from mobiles_n where mobile_id=?";
	public static final String UPDATE_MOBILE="update mobiles_n set price=? where mobile_id=?";
	public static final String GET_MOBILE_DETAILS="{call get_mobile_details(?,?,?,?)}";
	public static final String GET_MOBILE_PRICE="{?=call get_mobile_price(?)}";
}
